import { useEffect, useRef, useState } from 'react';
import {
  createBrowserRouter,
  Outlet,
  RouterProvider,
  useLocation,
} from "react-router-dom";
import { useAppDispatch } from '@/redux/hooks';
import NotFound from 'components/share/not.found';
import LoginPage from 'pages/auth/login';
import RegisterPage from 'pages/auth/register';
import LayoutAdmin from 'components/admin/layout.admin';
import ProtectedRoute from 'components/share/protected-route.ts';
import Header from 'components/client/header.client';
import Footer from 'components/client/footer.client';
import HomePage from 'pages/home';
import styles from 'styles/app.module.scss';
import DashboardPage from './pages/admin/dashboard';
import CompanyPage from './pages/admin/company';
import PermissionPage from './pages/admin/permission';
import ResumePage from './pages/admin/resume';
import RolePage from './pages/admin/role';
import UserPage from './pages/admin/user';
import { fetchAccount } from './redux/slice/accountSlide';
import LayoutApp from './components/share/layout.app';
import ViewUpsertJob from './components/admin/job/upsert.job';
import ClientJobPage from './pages/job';
import ClientJobDetailPage from './pages/job/detail';
import ClientCompanyPage from './pages/company';
import ClientCompanyDetailPage from './pages/company/detail';
import JobTabs from './pages/admin/job/job.tabs';

const LayoutClient = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const location = useLocation();
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (rootRef && rootRef.current) {
      rootRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [location]);

  return (
    <div className='layout-app' ref={rootRef}>
      <Header searchTerm={searchTerm} setSearchTerm={setSearchTerm} />
      <div className={styles['content-app']}>
        <Outlet context={[searchTerm, setSearchTerm]} />
      </div>
      <Footer />
    </div>
  )
}

// ✅ QUAN TRỌNG: router phải đặt NGOÀI component
// Nếu đặt trong App() → mỗi lần Redux thay đổi (isLoading...) App re-render
// → createBrowserRouter chạy lại → router mới → RouterProvider reset navigation
// → navigate('/admin') bị hủy → bật về '/'
const router = createBrowserRouter([
  {
    path: "/",
    element: (<LayoutApp><LayoutClient /></LayoutApp>),
    errorElement: <NotFound />,
    children: [
      { index: true, element: <HomePage /> },
      { path: "job", element: <ClientJobPage /> },
      { path: "job/:id", element: <ClientJobDetailPage /> },
      { path: "company", element: <ClientCompanyPage /> },
      { path: "company/:id", element: <ClientCompanyDetailPage /> }
    ],
  },
  {
    path: "/admin",
    element: (<LayoutApp><LayoutAdmin /></LayoutApp>),
    errorElement: <NotFound />,
    children: [
      {
        index: true,
        element: <ProtectedRoute><DashboardPage /></ProtectedRoute>
      },
      {
        path: "company",
        element: <ProtectedRoute><CompanyPage /></ProtectedRoute>
      },
      {
        path: "user",
        element: <ProtectedRoute><UserPage /></ProtectedRoute>
      },
      {
        path: "job",
        children: [
          { index: true, element: <ProtectedRoute><JobTabs /></ProtectedRoute> },
          { path: "upsert", element: <ProtectedRoute><ViewUpsertJob /></ProtectedRoute> }
        ]
      },
      {
        path: "resume",
        element: <ProtectedRoute><ResumePage /></ProtectedRoute>
      },
      {
        path: "permission",
        element: <ProtectedRoute><PermissionPage /></ProtectedRoute>
      },
      {
        path: "role",
        element: <ProtectedRoute><RolePage /></ProtectedRoute>
      }
    ],
  },
  { path: "/login", element: <LoginPage /> },
  { path: "/register", element: <RegisterPage /> },
]);

export default function App() {
  const dispatch = useAppDispatch();
  // ✅ KHÔNG subscribe isLoading ở đây — tránh App re-render khi Redux thay đổi

  useEffect(() => {
    if (
      window.location.pathname === '/login'
      || window.location.pathname === '/register'
    ) return;
    dispatch(fetchAccount());
  }, []);

  return <RouterProvider router={router} />;
}
